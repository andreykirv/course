﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {

        public void Clear(DataGridView dataGridView)
        {
            while (dataGridView.Rows.Count > 1)
                for (int i = 0; i < dataGridView.Rows.Count - 1; i++)
                    dataGridView.Rows.Remove(dataGridView.Rows[i]);
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filePath = "base.xml";

            AuthorsDataSet.ReadXml(filePath);
            dataGridView1.DataSource = AuthorsDataSet;
            dataGridView1.DataMember = "saying";


            dataGridView1.Columns[0].Width = 400;
            dataGridView1.Columns[1].Width = 105;
            dataGridView1.Columns[2].Width = 105;
            dataGridView1.Columns[3].Width = 105;
            dataGridView1.Columns[4].Width = 105;
            dataGridView1.Columns[5].Width = 105;
        }

        private void dataGridView1_AutoSizeColumnModeChanged(object sender, DataGridViewAutoSizeColumnModeEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void search_Click(object sender, EventArgs e)
        {
            Clear(dataGridView1);
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load("base.xml");
            XmlElement xRoot = xDoc.DocumentElement;
            foreach (XmlNode xnode in xRoot)
            {
                foreach (XmlNode childnode in xnode.ChildNodes)
                {
                    if (childnode.InnerText == "Стив Джобс")
                    {
                        //string saying = childnode.InnerText;
                        //listBox1.Items.Add(xnode.InnerText);
                        //dataGridView1.Rows.Add(xnode.InnerText);
                        //Console.WriteLine("Компания: {0}", childnode.InnerText);
                    }
                }
            }
        }

       

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
